Dear Instructors,

The submitted files and their descriptions are as under:

1. data.json - contains a mini data of 10 movies with following properties: movieName, director and plot. This details are taken from Wikipedia by searching manually.
2. query_and_result.png - contains the screenshot of the query and the result of its execution.

Additionally load.py is provided to show the Python file used to load the data.

Best,
Aditya Dave.
