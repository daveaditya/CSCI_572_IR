Dear Instructors,

The submitted code was ran on the "NEW DATASET" provided i.e. data2.zip.

Mapper-Reducer code can be found in the unigram_code.java and bigram_code.java for Unigram and Bigram Jobs respectively.

Thanks.