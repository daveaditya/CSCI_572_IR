Note to Instructors,

The homework was done using Java (crawler4j). The source code is present in the "source_code" directory which is a gradle project. A README.md is present to follow the project structure and setup.

Also attached submission files.